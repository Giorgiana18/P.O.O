#pragma once
#include "LoyaltyScheme.h"
using namespace System;
ref class CreditCardAccount
{
private:
	LoyaltyScheme ^scheme;
public:
	void RedeemLoyaltyPoints();
public:
	literal String^ name = "Super Platinum Card";
private:
	static double interesRate;
public:
	static int GetNumberOfAccounts();
private :
	static int numberOfAccounts = 0;
public:
	CreditCardAccount(long number, double limit);
public:
	void SetCreditLimit(double amount);
	bool MakePurchase(double amount);
	void MakeRepayment(double amount);
	void PrintStatement();
	long GetAccountNumber();
	static CreditCardAccount();
private:
    long accountNumber;
	double currentBalance;
	double creditLimit;
};