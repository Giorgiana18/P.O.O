#pragma once

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	protected:
	private: System::Windows::Forms::Button^ sterge_tot;
	private: System::Windows::Forms::Button^ inpartire;
	private: System::Windows::Forms::Button^ inmultire;
	private: System::Windows::Forms::Button^ minus;
	private: System::Windows::Forms::Button^ plus;
	private: System::Windows::Forms::Button^ sterge;
	private: System::Windows::Forms::Button^ numar_0;
	private: System::Windows::Forms::Button^ numar_9;
	private: System::Windows::Forms::Button^ numar_8;
	private: System::Windows::Forms::Button^ numar_7;
	private: System::Windows::Forms::Button^ numar_6;
	private: System::Windows::Forms::Button^ numar_5;
	private: System::Windows::Forms::Button^ numar_4;
	private: System::Windows::Forms::Button^ numar_3;
	private: System::Windows::Forms::Button^ numarul_2;
	private: System::Windows::Forms::Button^ numarul_1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ calculeaza;

	private: System::Windows::Forms::TextBox^ textBox1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->sterge_tot = (gcnew System::Windows::Forms::Button());
			this->inpartire = (gcnew System::Windows::Forms::Button());
			this->inmultire = (gcnew System::Windows::Forms::Button());
			this->minus = (gcnew System::Windows::Forms::Button());
			this->plus = (gcnew System::Windows::Forms::Button());
			this->sterge = (gcnew System::Windows::Forms::Button());
			this->numar_0 = (gcnew System::Windows::Forms::Button());
			this->numar_9 = (gcnew System::Windows::Forms::Button());
			this->numar_8 = (gcnew System::Windows::Forms::Button());
			this->numar_7 = (gcnew System::Windows::Forms::Button());
			this->numar_6 = (gcnew System::Windows::Forms::Button());
			this->numar_5 = (gcnew System::Windows::Forms::Button());
			this->numar_4 = (gcnew System::Windows::Forms::Button());
			this->numar_3 = (gcnew System::Windows::Forms::Button());
			this->numarul_2 = (gcnew System::Windows::Forms::Button());
			this->numarul_1 = (gcnew System::Windows::Forms::Button());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->calculeaza = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->panel1->Controls->Add(this->sterge_tot);
			this->panel1->Controls->Add(this->inpartire);
			this->panel1->Controls->Add(this->inmultire);
			this->panel1->Controls->Add(this->minus);
			this->panel1->Controls->Add(this->plus);
			this->panel1->Controls->Add(this->sterge);
			this->panel1->Controls->Add(this->numar_0);
			this->panel1->Controls->Add(this->numar_9);
			this->panel1->Controls->Add(this->numar_8);
			this->panel1->Controls->Add(this->numar_7);
			this->panel1->Controls->Add(this->numar_6);
			this->panel1->Controls->Add(this->numar_5);
			this->panel1->Controls->Add(this->numar_4);
			this->panel1->Controls->Add(this->numar_3);
			this->panel1->Controls->Add(this->numarul_2);
			this->panel1->Controls->Add(this->numarul_1);
			this->panel1->Location = System::Drawing::Point(6, 169);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(553, 296);
			this->panel1->TabIndex = 0;
			// 
			// sterge_tot
			// 
			this->sterge_tot->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->sterge_tot->Location = System::Drawing::Point(262, 16);
			this->sterge_tot->Name = L"sterge_tot";
			this->sterge_tot->Size = System::Drawing::Size(75, 51);
			this->sterge_tot->TabIndex = 15;
			this->sterge_tot->Text = L"C";
			this->sterge_tot->UseVisualStyleBackColor = true;
			this->sterge_tot->Click += gcnew System::EventHandler(this, &Form1::sterge_tot_Click);
			// 
			// inpartire
			// 
			this->inpartire->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->inpartire->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->inpartire->Location = System::Drawing::Point(470, 210);
			this->inpartire->Name = L"inpartire";
			this->inpartire->Size = System::Drawing::Size(75, 64);
			this->inpartire->TabIndex = 14;
			this->inpartire->Text = L"/";
			this->inpartire->UseVisualStyleBackColor = false;
			this->inpartire->Click += gcnew System::EventHandler(this, &Form1::inpartire_Click);
			// 
			// inmultire
			// 
			this->inmultire->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->inmultire->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->inmultire->Location = System::Drawing::Point(470, 146);
			this->inmultire->Name = L"inmultire";
			this->inmultire->Size = System::Drawing::Size(75, 58);
			this->inmultire->TabIndex = 13;
			this->inmultire->Text = L"*";
			this->inmultire->UseVisualStyleBackColor = false;
			this->inmultire->Click += gcnew System::EventHandler(this, &Form1::inmultire_Click);
			// 
			// minus
			// 
			this->minus->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->minus->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->minus->Location = System::Drawing::Point(470, 79);
			this->minus->Name = L"minus";
			this->minus->Size = System::Drawing::Size(75, 61);
			this->minus->TabIndex = 12;
			this->minus->Text = L"-";
			this->minus->UseVisualStyleBackColor = false;
			this->minus->Click += gcnew System::EventHandler(this, &Form1::minus_Click);
			// 
			// plus
			// 
			this->plus->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->plus->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->plus->Location = System::Drawing::Point(470, 10);
			this->plus->Name = L"plus";
			this->plus->Size = System::Drawing::Size(75, 63);
			this->plus->TabIndex = 11;
			this->plus->Text = L"+";
			this->plus->UseVisualStyleBackColor = false;
			this->plus->Click += gcnew System::EventHandler(this, &Form1::plus_Click);
			// 
			// sterge
			// 
			this->sterge->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->sterge->Location = System::Drawing::Point(343, 22);
			this->sterge->Name = L"sterge";
			this->sterge->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->sterge->Size = System::Drawing::Size(121, 45);
			this->sterge->TabIndex = 10;
			this->sterge->Text = L"sterge";
			this->sterge->UseVisualStyleBackColor = true;
			this->sterge->Click += gcnew System::EventHandler(this, &Form1::sterge_Click);
			// 
			// numar_0
			// 
			this->numar_0->BackColor = System::Drawing::Color::Cyan;
			this->numar_0->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_0->Location = System::Drawing::Point(91, 235);
			this->numar_0->Name = L"numar_0";
			this->numar_0->Size = System::Drawing::Size(75, 51);
			this->numar_0->TabIndex = 9;
			this->numar_0->Text = L"0";
			this->numar_0->UseVisualStyleBackColor = false;
			this->numar_0->Click += gcnew System::EventHandler(this, &Form1::numar_0_Click);
			// 
			// numar_9
			// 
			this->numar_9->BackColor = System::Drawing::Color::Cyan;
			this->numar_9->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_9->Location = System::Drawing::Point(172, 153);
			this->numar_9->Name = L"numar_9";
			this->numar_9->Size = System::Drawing::Size(75, 51);
			this->numar_9->TabIndex = 8;
			this->numar_9->Text = L"9";
			this->numar_9->UseVisualStyleBackColor = false;
			this->numar_9->Click += gcnew System::EventHandler(this, &Form1::numar_9_Click);
			// 
			// numar_8
			// 
			this->numar_8->BackColor = System::Drawing::Color::Cyan;
			this->numar_8->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_8->Location = System::Drawing::Point(91, 153);
			this->numar_8->Name = L"numar_8";
			this->numar_8->Size = System::Drawing::Size(75, 51);
			this->numar_8->TabIndex = 7;
			this->numar_8->Text = L"8";
			this->numar_8->UseVisualStyleBackColor = false;
			this->numar_8->Click += gcnew System::EventHandler(this, &Form1::numar_8_Click);
			// 
			// numar_7
			// 
			this->numar_7->BackColor = System::Drawing::Color::Cyan;
			this->numar_7->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_7->Location = System::Drawing::Point(10, 153);
			this->numar_7->Name = L"numar_7";
			this->numar_7->Size = System::Drawing::Size(75, 51);
			this->numar_7->TabIndex = 6;
			this->numar_7->Text = L"7";
			this->numar_7->UseVisualStyleBackColor = false;
			this->numar_7->Click += gcnew System::EventHandler(this, &Form1::numar_7_Click);
			// 
			// numar_6
			// 
			this->numar_6->BackColor = System::Drawing::Color::Cyan;
			this->numar_6->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_6->Location = System::Drawing::Point(172, 78);
			this->numar_6->Name = L"numar_6";
			this->numar_6->Size = System::Drawing::Size(75, 51);
			this->numar_6->TabIndex = 5;
			this->numar_6->Text = L"6";
			this->numar_6->UseVisualStyleBackColor = false;
			this->numar_6->Click += gcnew System::EventHandler(this, &Form1::numar_6_Click);
			// 
			// numar_5
			// 
			this->numar_5->BackColor = System::Drawing::Color::Cyan;
			this->numar_5->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_5->Location = System::Drawing::Point(91, 78);
			this->numar_5->Name = L"numar_5";
			this->numar_5->Size = System::Drawing::Size(75, 51);
			this->numar_5->TabIndex = 4;
			this->numar_5->Text = L"5";
			this->numar_5->UseVisualStyleBackColor = false;
			this->numar_5->Click += gcnew System::EventHandler(this, &Form1::numar_5_Click);
			// 
			// numar_4
			// 
			this->numar_4->BackColor = System::Drawing::Color::Cyan;
			this->numar_4->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_4->Location = System::Drawing::Point(10, 78);
			this->numar_4->Name = L"numar_4";
			this->numar_4->Size = System::Drawing::Size(75, 51);
			this->numar_4->TabIndex = 3;
			this->numar_4->Text = L"4";
			this->numar_4->UseVisualStyleBackColor = false;
			this->numar_4->Click += gcnew System::EventHandler(this, &Form1::numar_4_Click);
			// 
			// numar_3
			// 
			this->numar_3->BackColor = System::Drawing::Color::Cyan;
			this->numar_3->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numar_3->Location = System::Drawing::Point(172, 9);
			this->numar_3->Name = L"numar_3";
			this->numar_3->Size = System::Drawing::Size(75, 51);
			this->numar_3->TabIndex = 2;
			this->numar_3->Text = L"3";
			this->numar_3->UseVisualStyleBackColor = false;
			this->numar_3->Click += gcnew System::EventHandler(this, &Form1::numar_3_Click);
			// 
			// numarul_2
			// 
			this->numarul_2->BackColor = System::Drawing::Color::Cyan;
			this->numarul_2->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numarul_2->Location = System::Drawing::Point(91, 9);
			this->numarul_2->Name = L"numarul_2";
			this->numarul_2->Size = System::Drawing::Size(75, 51);
			this->numarul_2->TabIndex = 1;
			this->numarul_2->Text = L"2";
			this->numarul_2->UseVisualStyleBackColor = false;
			this->numarul_2->Click += gcnew System::EventHandler(this, &Form1::numarul_2_Click);
			// 
			// numarul_1
			// 
			this->numarul_1->BackColor = System::Drawing::Color::Cyan;
			this->numarul_1->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numarul_1->Location = System::Drawing::Point(10, 9);
			this->numarul_1->Name = L"numarul_1";
			this->numarul_1->Size = System::Drawing::Size(75, 51);
			this->numarul_1->TabIndex = 0;
			this->numarul_1->Text = L"1";
			this->numarul_1->UseVisualStyleBackColor = false;
			this->numarul_1->Click += gcnew System::EventHandler(this, &Form1::numarul_1_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->panel2->Controls->Add(this->calculeaza);
			this->panel2->Controls->Add(this->textBox1);
			this->panel2->Location = System::Drawing::Point(6, 2);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(545, 161);
			this->panel2->TabIndex = 1;
			// 
			// calculeaza
			// 
			this->calculeaza->Font = (gcnew System::Drawing::Font(L"Georgia", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->calculeaza->Location = System::Drawing::Point(456, 98);
			this->calculeaza->Name = L"calculeaza";
			this->calculeaza->Size = System::Drawing::Size(73, 50);
			this->calculeaza->TabIndex = 2;
			this->calculeaza->Text = L"=";
			this->calculeaza->UseVisualStyleBackColor = true;
			this->calculeaza->Click += gcnew System::EventHandler(this, &Form1::calculeaza_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(3, 10);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(535, 147);
			this->textBox1->TabIndex = 0;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(559, 461);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->panel1->ResumeLayout(false);
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void numarul_2_Click(System::Object^ sender, System::EventArgs^ e) {
		textBox1->Text += "2";
	}
private: System::Void numar_3_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "3";
	}
private: System::Void sterge_tot_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Clear();
	}
private: System::Void sterge_Click(System::Object^ sender, System::EventArgs^ e) {

	}
  private: double firstNum = 0;
  private: double secondNum= 0;
  private: String^ operation="";
private: System::Void plus_Click(System::Object^ sender, System::EventArgs^ e) {
   if (textBox1->Text != " ")
	{
		firstNum = Double::Parse(textBox1->Text);
		textBox1->Text = "";
		operation = "+";
		textBox1->Text = "";
	}

	}
private: System::Void minus_Click(System::Object^ sender, System::EventArgs^ e) {
	if (textBox1->Text!= " ")
	{
		firstNum = Double::Parse(textBox1->Text);
		textBox1->Text = "";
		operation = "-";
		textBox1->Text = "";
	}
	}
private: System::Void inmultire_Click(System::Object^ sender, System::EventArgs^ e) {
	
	if (textBox1->Text != " ")
	{
		firstNum = Double::Parse(textBox1->Text);
		textBox1->Text = "";
		operation = "*";
		textBox1->Text = "";
	}
	}
private: System::Void inpartire_Click(System::Object^ sender, System::EventArgs^ e) {
	
	if (textBox1->Text != " ")
	{
		firstNum = Double::Parse(textBox1->Text);
		textBox1->Text = "";
		operation = "/";
		textBox1->Text = "";
	}
	}
private: System::Void numar_0_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "0";
	}
private: System::Void numar_9_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "9";
	}
private: System::Void numar_8_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "8";
	}
private: System::Void numar_7_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "7";
	}
private: System::Void numar_4_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "4";
	}
private: System::Void numar_5_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "5";
	}
private: System::Void numar_6_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "6";
	}
private: System::Void numarul_1_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text += "1";
}

private: System::Void calculeaza_Click(System::Object^ sender, System::EventArgs^ e) {
	if (textBox1->Text != "")
	{
		secondNum = Double::Parse(textBox1->Text);
		if (operation == "+")
		{
			textBox1->Text = (firstNum + secondNum).ToString();
		}
		else
			if (operation == "-")
			{
				textBox1->Text = (firstNum - secondNum).ToString();

			}
			else
				if (operation == "*")
				{
					textBox1->Text = (firstNum * secondNum).ToString();

				}
				else
					if (operation=="/")
					{
						if (secondNum != 0)
						{
							textBox1->Text = (firstNum / secondNum).ToString();
						}
						else
							textBox1->Text = "Error: Cannot divide by zero";

					}

	}

}
};
}
