#pragma once

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ input_cnp;
	private: System::Windows::Forms::TextBox^ afisaj_cnp;
	protected:

	protected:

	private: System::Windows::Forms::Button^ calculeaza_cnp;
	private: System::Windows::Forms::Button^ sterge_input;
	private: System::Windows::Forms::Button^ afisaj_data;


	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ Sex_cnp;
	private: System::Windows::Forms::Label^ gen_cnp;
	private: System::Windows::Forms::Button^ Afiseaza_genul;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->input_cnp = (gcnew System::Windows::Forms::TextBox());
			this->afisaj_cnp = (gcnew System::Windows::Forms::TextBox());
			this->calculeaza_cnp = (gcnew System::Windows::Forms::Button());
			this->sterge_input = (gcnew System::Windows::Forms::Button());
			this->afisaj_data = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Sex_cnp = (gcnew System::Windows::Forms::Label());
			this->gen_cnp = (gcnew System::Windows::Forms::Label());
			this->Afiseaza_genul = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// input_cnp
			// 
			this->input_cnp->Location = System::Drawing::Point(13, 27);
			this->input_cnp->Multiline = true;
			this->input_cnp->Name = L"input_cnp";
			this->input_cnp->Size = System::Drawing::Size(226, 76);
			this->input_cnp->TabIndex = 0;
			// 
			// afisaj_cnp
			// 
			this->afisaj_cnp->Location = System::Drawing::Point(13, 188);
			this->afisaj_cnp->Multiline = true;
			this->afisaj_cnp->Name = L"afisaj_cnp";
			this->afisaj_cnp->Size = System::Drawing::Size(226, 76);
			this->afisaj_cnp->TabIndex = 1;
			this->afisaj_cnp->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// calculeaza_cnp
			// 
			this->calculeaza_cnp->Location = System::Drawing::Point(24, 133);
			this->calculeaza_cnp->Name = L"calculeaza_cnp";
			this->calculeaza_cnp->Size = System::Drawing::Size(75, 23);
			this->calculeaza_cnp->TabIndex = 2;
			this->calculeaza_cnp->Text = L"Calculeaza";
			this->calculeaza_cnp->UseVisualStyleBackColor = true;
			this->calculeaza_cnp->Click += gcnew System::EventHandler(this, &Form1::calculeaza_cnp_Click);
			// 
			// sterge_input
			// 
			this->sterge_input->Location = System::Drawing::Point(146, 133);
			this->sterge_input->Name = L"sterge_input";
			this->sterge_input->Size = System::Drawing::Size(75, 23);
			this->sterge_input->TabIndex = 3;
			this->sterge_input->Text = L"CNP";
			this->sterge_input->UseVisualStyleBackColor = true;
			this->sterge_input->Click += gcnew System::EventHandler(this, &Form1::sterge_input_Click);
			// 
			// afisaj_data
			// 
			this->afisaj_data->Location = System::Drawing::Point(368, 80);
			this->afisaj_data->Name = L"afisaj_data";
			this->afisaj_data->Size = System::Drawing::Size(75, 23);
			this->afisaj_data->TabIndex = 4;
			this->afisaj_data->Text = L"Afiseaza";
			this->afisaj_data->UseVisualStyleBackColor = true;
			this->afisaj_data->Click += gcnew System::EventHandler(this, &Form1::afisaj_data_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(368, 42);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(44, 16);
			this->label1->TabIndex = 5;
			this->label1->Text = L"DATA";
			// 
			// Sex_cnp
			// 
			this->Sex_cnp->AutoSize = true;
			this->Sex_cnp->Location = System::Drawing::Point(368, 119);
			this->Sex_cnp->Name = L"Sex_cnp";
			this->Sex_cnp->Size = System::Drawing::Size(0, 16);
			this->Sex_cnp->TabIndex = 6;
			// 
			// gen_cnp
			// 
			this->gen_cnp->AutoSize = true;
			this->gen_cnp->Location = System::Drawing::Point(371, 139);
			this->gen_cnp->Name = L"gen_cnp";
			this->gen_cnp->Size = System::Drawing::Size(32, 16);
			this->gen_cnp->TabIndex = 7;
			this->gen_cnp->Text = L"Gen";
			// 
			// Afiseaza_genul
			// 
			this->Afiseaza_genul->Location = System::Drawing::Point(368, 178);
			this->Afiseaza_genul->Name = L"Afiseaza_genul";
			this->Afiseaza_genul->Size = System::Drawing::Size(75, 23);
			this->Afiseaza_genul->TabIndex = 8;
			this->Afiseaza_genul->Text = L"Afiseaza gen";
			this->Afiseaza_genul->UseVisualStyleBackColor = true;
			this->Afiseaza_genul->Click += gcnew System::EventHandler(this, &Form1::Afiseaza_genul_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(532, 398);
			this->Controls->Add(this->Afiseaza_genul);
			this->Controls->Add(this->gen_cnp);
			this->Controls->Add(this->Sex_cnp);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->afisaj_data);
			this->Controls->Add(this->sterge_input);
			this->Controls->Add(this->calculeaza_cnp);
			this->Controls->Add(this->afisaj_cnp);
			this->Controls->Add(this->input_cnp);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void afisaj_data_Click(System::Object^ sender, System::EventArgs^ e) {
	DateTime today = DateTime::Now;
	label1->Text = today.ToString("dd/MM/yyyy");
}
	private: System::Void sterge_input_Click(System::Object^ sender, System::EventArgs^ e) {
		input_cnp->Clear();
		afisaj_cnp->Clear();
	}
private: System::Void calculeaza_cnp_Click(System::Object ^ sender, System::EventArgs ^ e) {
	if (input_cnp->Text->Length == 0)
	{
		MessageBox::Show("Introduceti CNP-UL", "Eroare", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		return;
	}
	else
	{
		String^ cnp = input_cnp->Text;
		int an;
		if (cnp->Substring(0, 1) == "1" || cnp->Substring(0, 1) == "2") {
			// CNP-ul este din anii 1900-1999
			an = Int32::Parse(cnp->Substring(1, 2));
			an = an + 1900;
		}
		else if (cnp->Substring(0, 1) == "3" || cnp->Substring(0, 1) == "4") {
			// CNP-ul este din anii 1800-1899
			an = Int32::Parse(cnp->Substring(1, 2));
			an = an + 1800;
		}
		else if (cnp->Substring(0, 1) == "5" || cnp->Substring(0, 1) == "6") {
			// CNP-ul este din anii 2000-2099
			an = Int32::Parse(cnp->Substring(1, 2));
			an = an + 2000;
		}
		else if (cnp->Substring(0, 1) == "7" || cnp->Substring(0, 1) == "8" || cnp->Substring(0, 1) == "9") {
			// CNP-ul este din anii 1900-1999 (pentru persoanele straine)
			an = Int32::Parse(cnp->Substring(1, 2));
			an = an + 1900;
		}
		else {
			// CNP invalid
			MessageBox::Show("CNP invalid", "Eroare", MessageBoxButtons::OK, MessageBoxIcon::Warning);
			return;
		}
		int luna = Int32::Parse(cnp->Substring(3, 2));
		int zi = Int32::Parse(cnp->Substring(5, 2));
		DateTime azi = DateTime::Now;
		int anul_nasterii = 1990;
		int luna_nasterii = 1;
		int ziua = 1;
		int an_curent = DateTime.Now.Year;
		int luna_curenta = DateTime.Now.Month;
		int ziua_curenta = DateTime.Now.Day;
		if (anul_nasterii >= 0 && anul_nasterii <= 99)
		{
			anul_nasterii += 1900;
		}
		else if (anul_nasterii >= 1000 && anul_nasterii <= an_curent % 100)
		{
			anul_nasterii += 1000;
		}

		int varsta = an_curent - anul_nasterii;
		if (luna_curenta < luna_nasterii || (luna_curenta == luna_nasterii && ziua_curenta < ziua))
		{
			varsta--;
		}
		afisaj_cnp->Text = "Data nasterii" + zi.ToString() + "/" + luna.ToString() + "/" + an.ToString() + "\n" + "Varsta:" + varsta.ToString();
	}
}
private: System::Void Afiseaza_genul_Click(System::Object^ sender, System::EventArgs^ e) {
	if (input_cnp->Text->Length == 0)
	{
		MessageBox::Show("Introduceti CNP-UL", "Eroare", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		return;
	}
	else
	{
		String^ cnp = input_cnp->Text;
		int sex = Int32::Parse(cnp->Substring(0, 1));
		if (sex == 1 || sex == 5)
			gen_cnp->Text = "Gen:Masculin";
		else if (sex == 2 || sex == 6)
			gen_cnp->Text = "Gen:Feminin";
		else if (sex == 3 || sex == 7)
			gen_cnp->Text = "Gen:Masculin provenit din alta tara";
		else if (sex == 4 || sex == 8)
			gen_cnp->Text = "Gen:Feminin provenit din alta tara";
		else
			gen_cnp->Text = "CNP ul introdus nu este corect,fie nu este cetatean roman";
	}

}
};
}
