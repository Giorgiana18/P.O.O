﻿#include <iostream>
#include <string>
using namespace std;
string nume[50];
string numar_de_telefon[50];
string numar_de_mobil[50];
string numar_fax[50];
string email[50];
string adresa[50];
int contor = -1;
int valideaza_Contact(string Nume)
{
	for (int i = 0; i <= contor; i++)
	{
		if (nume[i] == Nume)
		{
			return 0;
		}
	}
	return 1;
}
bool este_numar(const string& str)
{
	int i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < '0' || str[i]>'9')
		{
			return false;
		}
		i++;
	}
	return true;
}
void adauga_Contact()
{
	string Nume = "";
	cout << "Introduceti numele: ";
	cin >> Nume;
	if (valideaza_Contact(Nume) == 0)
	{
		cout << endl << "Exista deja un contact cu acest nume" << endl;
		return;
	}
	contor++;
	nume[contor] = Nume;
	string NrTelefon;
	cout << "Doriti sa introduceti un numarul de telefon?(da/nu)";
	cin >> NrTelefon;
	if (NrTelefon == "da")
	{
		if (!este_numar(NrTelefon))
		{
			cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
			contor--;
			return;
		}
		else
		{
			NrTelefon = "";
		}
		numar_de_telefon[contor] = NrTelefon;
		string NrMobil;
		cout << "Doriti sa introduceti un numarul de mobil?(da/nu) ";
		cin >> NrMobil;
		if (NrMobil == "da")
		{
			if (!este_numar(NrMobil))
			{
				cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
				contor--;
				return;
			}
			else
			{
				NrMobil = "";
			}
			numar_de_mobil[contor] = NrMobil;
			string NrFax;
			cout << "Doriti sa introduceti un numarul de fax?(da/nu) ";
			cin >> NrFax;
			if (NrFax == "da")
			{
				if (!este_numar(NrFax))
				{
					cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
					contor--;
					return;
				}
				else
				{
					NrFax = "";
				}
				numar_fax[contor] = NrFax;
				string Email;
				cout << "Doriti sa introduceti adresa de email?(da/nu) ";
				cin >> Email;
				if (Email == "da")
				{
					cout << "Introduceti adresa de email:";
					cin >> Email;
				}
				else
				{
					Email = "";
				}
				string Adresa;
				cout << "Doriti sa introduceti adresa de domiciliu?(da/nu) ";
				cin >> Adresa;
				if (Adresa == "da")
				{
					cout << "Introduceti adresa de domiciliu:";
					cin >> Adresa;
				}
				else
				{
					Adresa = "";
				}
			}
			void afisare(int Contor)
			{
				if (nume[Contor] == "")
					return;
				if (contor > -1)
				{
					cout << "Nume: " << nume[Contor] << endl;
					cout << "Numar de telefon: " << numar_de_telefon[Contor] << endl;
					cout << "Numar de mobil: " << numar_de_mobil[Contor] << endl;
					cout << "Email: " << email[Contor] << endl;
					cout << "Adresa:" << adresa[Contor] << endl;
					cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua..." << endl << endl;
					cin.get();
				}
			}
			void afiseaza_TOT()
			{
				if (contor > -1)
				{
					for (int i = 0; i <= contor; i++)
					{
						afisare(i);
					}
				}
			}
			void actualizeaza_contact(int Contor)
			{
				string Nume = "";
				cout << "Introduceti numele: ";
				cin >> Nume;
				if (valideaza_Contact(Nume) == 0)
				{
					cout << endl << "Exista deja un contact cu acest nume" << endl;
					return;
				}
				contor++;
				nume[contor] = Nume;
				string NrTelefon;
				cout << "Doriti sa introduceti un numarul de telefon?(da/nu)";
				cin >> NrTelefon;
				if (NrTelefon == "da")
				{
					if (!este_numar(NrTelefon))
					{
						cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
						contor--;
						return;
					}
					else
					{
						NrTelefon = "";
					}
					numar_de_telefon[contor] = NrTelefon;
					string NrMobil;
					cout << "Doriti sa actualizati numarul de mobil?(da/nu) ";
					cin >> NrMobil;
					if (NrMobil == "da")
					{
						if (!este_numar(NrMobil))
						{
							cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
							contor--;
							return;
						}
						else
						{
							NrMobil = "";
						}
						numar_de_mobil[contor] = NrMobil;
						string NrFax;
						cout << "Doriti sa actualizati numarul de fax?(da/nu) ";
						cin >> NrFax;
						if (NrFax == "da")
						{
							if (!este_numar(NrFax))
							{
								cout << "Numarul de telefon trebuie sa contina doar cifre." << endl;
								contor--;
								return;
							}
							else
							{
								NrFax = "";
							}
							numar_fax[contor] = NrFax;
							string Email;
							cout << "Doriti sa actualizati adresa de email?(da/nu) ";
							cin >> Email;
							if (Email == "da")
							{
								cout << "Introduceti adresa de email:";
								cin >> Email;
							}
							else
							{
								Email = "";
							}
							string Adresa;
							cout << "Doriti sa actualizati adresa de domiciliu?(da/nu) ";
							cin >> Adresa;
							if (Adresa == "da")
							{
								cout << "Introduceti adresa de domiciliu:";
								cin >> Adresa;
							}
							else
							{
								Adresa = "";
							}
						}
						void sterge_contact(int Contor)
						{
							nume[Contor] = "";
							numar_de_telefon[Contor] = "";
							numar_de_mobil[Contor] = "";
							numar_fax[Contor] = "";
							email[Contor] = "";
							adresa[Contor] = "";
						}
						int cauta_contorul()
						{
							if (contor < 0)
								return -1;
							string Nume;
							cout << "Introduceti numele: ";
							cin >> Nume;
							for (int i = 0; i <= contor; i++)
							{
								if (nume[i] == Nume)
								{
									return i;
								}
							}
							return 1;
						}
						int main()
						{
							char optiune;
							do
							{
								cout << "1.Adauga contacte" << endl;
								cout << "2.Lista de contacte" << endl;
								cout << "3.Cauta contact" << endl;
								cout << "4.Actualizeaza contactul" << endl;
								cout << "5.Sterge contactul" << endl;
								cout << "6.Iesire" << endl << endl;
								cout << "Introduceti optiunea(1-6):";
								cin >> optiune;
								switch (optiune)
								{
								case '1':
								{
									adauga_Contact();
									cout << "Contact adugat cu succes" << endl;
									cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
									cin.get();
									break;
								}
								case '2':
								{
									afiseaza_TOT();
									break;
								}
								case '3':
								{
									int Contor = cauta_contorul();
									if (Contor > -1)
									{
										afisare(Contor);
									}
									break;
								}
								case '4':
								{
									int Contor = cauta_contorul();
									if (Contor > -1)
									{
										actualizeaza_contact(Contor);
										cout << "Contact actualizat cu succes." << endl;
									}
									else
									{
										cout << "Contactul nu a fost gasit." << endl;
									}
									cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
									cin.get();
									break;
								}
								case '5':
								{
									int Contor = cauta_contorul();
									if (Contor > -1)
									{
										sterge_contact(Contor);
										cout << "Contact sters cu succes." << endl;
									}
									else
									{
										cout << "Contactul nu a fost gasit." << endl;
									}
									cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
									cin.get();
									break;
								}
								case '6':
									cout << "Programul se inchide...";
									break;
								default:
									cout << "Optiune invalida.Va rugam sa incercati din nou." << endl;
									cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
									cin.get();
								}
							} while (optiune != '6');
							return 0;
						}
