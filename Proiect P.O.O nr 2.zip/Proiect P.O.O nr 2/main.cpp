#include <iostream>
#include <string>
using namespace std;
string nume[50];
string numar_de_telefon[50];
string numar_de_mobil[50];
string numar_fax[50];
string email[50];
string adresa[50];
int contor = -1;
int valideaza_Contact(string Nume)
{
	for (int i = 0; i <= contor; i++)
	{
		if (nume[i] == Nume)
		{
			return 0;
		}
	}
	return 1;
}
/*o funcție numită "valideaza_Contact" scopul funcției este de a valida dacă numele dat există deja într-o listă de contacte.
Dacă bucla "for" se încheie fără să găsească nicio potrivire între "Nume" și elementele din listă, funcția returnează valoarea 1,
 ceea ce poate însemna că numele dat este valid și nu există în listă.*/

bool este_numar(const string& str)
{
    int i=0;
    while(str[i]!='\0')
    {
        if(str[i]<'0' || str[i]>'9')
        {
            return false;
        }
        i++;
    }
    return true;
}
/*Funcția "este_numar"  parcurge fiecare caracter din string-ul "str" până când întâlnește caracterul de terminare a string-ului, '\0'.
În fiecare iterație a buclei, se verifică dacă caracterul curent, "str[i]", nu este un caracter numeric.
Aceasta se realizează prin comparația caracterei cu '0' și '9'.
 Dacă caracterul nu se încadrează în intervalul de caractere numerice ('0' - '9'), funcția returnează valoarea "false",
 semnificând că string-ul nu reprezintă un număr valid.
Dacă bucla se parcurge până la caracterul de terminare a string-ului fără a întâlni vreun caracter non-numeric,
funcția returnează valoarea "true", semnificând că string-ul este un număr valid.*/

void adauga_Contact()
{
	string Nume = "";
	cout<<"Introduceti numele: ";
	cin>>Nume;
	if (valideaza_Contact(Nume) == 0)
	{
		cout<<endl<<"Exista deja un contact cu acest nume"<<endl;
		return;
	}
	contor++;
	nume[contor]=Nume;/*Dacă numele este valid și nu există în listă, variabila "contor" este incrementată,
	                     indicând că s-a adăugat un contact nou. Numele contactului este apoi atribuit într-un vector
	                     numit "nume" la poziția corespunzătoare dată de "contor".*/
	string NrTelefon;
	cout<<"Doriti sa introduceti un numarul de telefon?(da/nu)";
	cin>>NrTelefon;
	if(NrTelefon=="da")
    {
        cout<<"Introduceti numarul de telefon:";
        cin>>NrTelefon;
	if(!este_numar(NrTelefon))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        contor--;
        return;
    }
    /*se verifică dacă acestea conțin doar cifre prin apelul funcției "este_numar".
      Dacă nu conțin doar cifre, se afișează un mesaj de eroare și se revine asupra incrementării variabilei
      "contor" pentru a indica că contactul nu a fost adăugat corect.*/
    }
    else
    {
        NrTelefon="";
    }
     numar_de_telefon[contor]=NrTelefon;
    string NrMobil;
	cout<<"Doriti sa introduceti un numarul de mobil?(da/nu) ";
	cin>>NrMobil;
	if(NrMobil=="da")
    {
        cout<<"Introduceti numarul de mobil:";
        cin>>NrMobil;
	if(!este_numar(NrMobil))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        contor--;
        return;
    }
    }
    else
    {
        NrMobil="";
    }
     numar_de_mobil[contor]=NrMobil;
    string NrFax;
	cout<<"Doriti sa introduceti un numarul de fax?(da/nu) ";
	cin>>NrFax;
	if(NrFax=="da")
    {
        cout<<"Introduceti numarul de fax:";
        cin>>NrFax;

	if(!este_numar(NrFax))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        contor--;
        return;//incheie functia
    }
    }
    else
    {
        NrFax="";
    }
    numar_fax[contor]=NrFax;
    string Email;
	cout<<"Doriti sa introduceti adresa de email?(da/nu) ";
	cin>>Email;
	if(Email=="da")
    {
        cout<<"Introduceti adresa de email:";
        cin>>Email;
    }
    else
    {
        Email="";
    }
    string Adresa;
	cout<<"Doriti sa introduceti adresa de domiciliu?(da/nu) ";
	cin>>Adresa;
	if(Adresa=="da")
    {
        cout<<"Introduceti adresa de domiciliu:";
        cin>>Adresa;
    }
    else
    {
        Adresa="";
    }
}
/*Funcția "adauga_Contact" permite utilizatorului să adauge un nou contact într-o listă de contacte.*/

void afisare(int Contor)
{
	if (nume[Contor] == "")
		return;
	if (contor > -1)
	{
		cout << "Nume: "<<nume[Contor]<<endl;
		cout << "Numar de telefon: "<<numar_de_telefon[Contor]<<endl;
		cout << "Numar de mobil: "<<numar_de_mobil[Contor]<<endl;
		cout << "Email: "<<email[Contor]<<endl;
		cout << "Adresa:"<<adresa[Contor]<<endl;
		cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua..." << endl << endl;
		cin.get();
	}
}
/*Scopul acestei funcții este de a afișa informațiile unui contact specific, identificat prin indicele "Contor"*/

void afiseaza_TOT()
{
	if (contor > -1)//se asigură că există cel puțin un contact în listă.
	{
		for (int i = 0; i <= contor; i++)
		{
			afisare(i);
		}
	}
}
/* funcția "afiseaza_TOT" afișează toate contactele din listă, în cazul în care există cel puțin un contact în listă.*/

void actualizeaza_contact(int Contor)
{
	string Nume = "";
	cout<<"Introduceti numele: ";
	cin>>Nume;
	if (valideaza_Contact(Nume) == 0)
	{
		cout<<endl<<"Exista deja un contact cu acest nume"<<endl;
		return;
	}
	nume[contor]=Nume;
	string NrTelefon;
	cout<<"Doriti sa actualizati un numarul de telefon?(da/nu)";
	cin>>NrTelefon;
	if(NrTelefon=="da")
    {
        cout<<"Introduceti numarul de telefon:";
        cin>>NrTelefon;
	if(!este_numar(NrTelefon))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        return;
    }
    }
    else
    {
        NrTelefon="";
    }
     numar_de_telefon[contor]=NrTelefon;
    string NrMobil;
	cout<<"Doriti sa actualizati un numarul de mobil?(da/nu) ";
	cin>>NrMobil;
	if(NrMobil=="da")
    {
        cout<<"Introduceti numarul de mobil:";
        cin>>NrMobil;

	if(!este_numar(NrMobil))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        return;
    }
    }
    else
    {
        NrMobil="";
    }
     numar_de_mobil[contor]=NrMobil;
    string NrFax;
	cout<<"Doriti sa actualizati un numarul de fax?(da/nu) ";

	if(NrFax=="da")
    {
        cout<<"Introduceti numarul de fax:";
        cin>>NrFax;
	if(!este_numar(NrFax))
    {
        cout<<"Numarul de telefon trebuie sa contina doar cifre."<<endl;
        return;
    }
    }
    else
    {
        NrFax="";
    }
    numar_fax[contor]=NrFax;
    string Email;
	cout<<"Doriti sa actualizati adresa de email?(da/nu) ";
	cin>>Email;
	if(Email=="da")
    {
        cout<<"Introduceti adresa de email:";
        cin>>Email;
    }
    else
    {
        Email="";
    }
    string Adresa;
	cout<<"Doriti sa actualizati adresa de domiciliu?(da/nu) ";
	cin>>Adresa;
	if(Adresa=="da")
    {
        cout<<"Introduceti adresa de domiciliu:";
        cin>>Adresa;
    }
    else
    {
        Adresa="";
    }
}
/*analog functie adauga_contact*/

void sterge_contact(int Contor)
{
	nume[Contor] = "";
	numar_de_telefon[Contor] = "";
	numar_de_mobil[Contor] = "";
	numar_fax[Contor] = "";
	email[Contor] = "";
	adresa[Contor] = "";
}
/*se elimină informațiile despre contactul respectiv din lista de contacte prin suprascrierea acestor informații cu string-uri goale*/

 int cauta_contorul()
{
	if (contor < 0)
		return -1;
	string Nume;
	cout << "Introduceti numele: ";
	cin >> Nume;
	for (int i = 0; i <= contor; i++)
	{
		if (nume[i] == Nume) /* se compară numele contactului de la poziția "i" din vectorul "nume" cu numele introdus de utilizator.
		                         dacă se găsește o potrivire, se returnează indicele "i", care reprezintă contorul contactului găsit.*/
		{
			return i;
		}
	}
	return 1;
}
/*are rolul de a căuta în lista de contacte indicele unui contact cu un anumit nume dat de utilizator.*/

int main()
{
	char optiune;
	do
	{
		cout << "1.Adauga contacte" << endl;
		cout << "2.Lista de contacte" << endl;
		cout << "3.Cauta contact" <<endl;
		cout << "4.Actualizeaza contactul" << endl;
		cout << "5.Sterge contactul" << endl;
		cout << "6.Iesire" << endl << endl;
		cout << "Introduceti optiunea(1-6):";
		cin >> optiune;
		//initializarea meniului

		switch (optiune)
		{
		case '1':
		{
			adauga_Contact();
			cout << "Contact adugat cu succes" << endl;
			cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
			cin.get();
			break;
		}
		/*Se apelează funcția "adauga_Contact()" pentru a adăuga un contact nou în listă.
		Se afișează mesajul "Contact adugat cu succes" și se așteaptă apăsarea unei taste de către utilizator pentru a continua.*/

		case '2':
		{
			afiseaza_TOT();
			break;
		}
		/*Se apelează funcția "afiseaza_TOT()" pentru a afișa lista de contacte existente.*/

		case '3':
		{
			int Contor = cauta_contorul();
			if (Contor > -1)
			{
				afisare(Contor);
			}
			break;
		}
		/*Se apelează funcția "cauta_contorul()" pentru a căuta contactul specificat de utilizator în listă.
		Dacă contactul este găsit (contorul este mai mare decât -1), se apelează funcția "afisare()"
		pentru a afișa informațiile despre contact.*/

		case '4':
		{
			int Contor = cauta_contorul();
			if (Contor > -1)
			{
				actualizeaza_contact(Contor);
				cout<<"Contact actualizat cu succes."<<endl;
			}
			else
            {
                cout<<"Contactul nu a fost gasit."<<endl;
            }
            cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
            cin.get();
			break;
		}
		/*Se apelează funcția "cauta_contorul()" pentru a căuta contactul specificat de utilizator în listă.
		Dacă contactul este găsit, se apelează funcția "actualizeaza_contact()" pentru a actualiza informațiile despre contact.
		Se afișează mesajul "Contact actualizat cu succes".*/

		case '5':
		{
			int Contor = cauta_contorul();
			if (Contor > -1)
			{
				sterge_contact(Contor);
				cout<<"Contact sters cu succes."<<endl;
			}
			else
            {
                cout<<"Contactul nu a fost gasit."<<endl;
            }
            cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
            cin.get();
			break;
		}
		/*Se apelează funcția "cauta_contorul()" pentru a căuta contactul specificat de utilizator în listă.
		Dacă contactul este găsit, se apelează funcția "sterge_contact()" pentru a șterge contactul din listă.
		Se afișează mesajul "Contact sters cu succes."*/

		case '6':
			cout<<"Programul se inchide...";
			break;
        default:
            cout<<"Optiune invalida.Va rugam sa incercati din nou."<<endl;
            cout << "Apasati orice tasta pentru a vizualiza urmatorul/continua...";
            cin.get();
       /*Se afișează mesajul "Programul se inchide..." și bucla se încheie, ieșind din meniu.
        Dacă opțiunea introdusă de utilizator nu corespunde niciunui caz, se afișează mesajul "Optiune invalida.
        Va rugam sa incercati din nou."*/
     }
	} while (optiune != '6');
	return 0;
}

