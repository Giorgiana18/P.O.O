#include <iostream>
#include <string>
using namespace std;
class Contact
{
public:
    string nume;
    string numar_telefon_fix;
    string numar_mobil;
    string email;
    string adresa;
     Contact()
     {
        nume = "";
        numar_telefon_fix = "";
        numar_mobil = "";
        email = "";
        adresa = "";
    }

    // Destructor
    ~Contact()
    {
    }

    void afisare()
    {
        cout<<"Nume:"<<nume<<endl;
        cout<<"Numar de telefon fix:"<<numar_telefon_fix<<endl;
        cout<<"Numar de mobil:"<<numar_mobil<<endl;
        cout<<"Email:"<<email<<endl;
        cout<<"Adresa:"<<adresa<<endl;
    }
};
/*Clasa "Contact" reprezintă o structură de date utilizată pentru a stoca informații despre un contact într-o agenda.
  Clasa conține un constructor fără parametri, numit "Contact()", care inițializează toate variabilele membru cu valoarea vidă.
  Clasa mai are o funcție numită "afisare()" care afișează informațiile despre contact.
  De asemenea, clasa include un destructor, "~Contact()", care nu conține cod*/

bool este_numar(const string& str)
{
    int i=0;
    while(str[i]!='\0')
    {
        if(str[i]<'0'|| str[i]>'9') /*verificare dacă caracterul este mai mic decât '0' sau dacă este mai mare decât '9'*/
        {
            return false;/*șirul de caractere nu reprezintă un număr.*/
        }
        i++;
    }
    return true;/*șirul de caractere  reprezintă un număr.*/
}
/*Această funcție poate fi utilă pentru a verifica dacă un șir de caractere introdus de utilizator reprezintă un număr valid într-un context specific,
  cum ar fi validarea unui număr de telefon sau a unui cod numeric.*/
int main()
{
    const int maxim_contacte=50;
    Contact contacte[maxim_contacte]; /*Se creează un array de obiecte de tip "Contact" numit "contacte", având dimensiunea "maxim_contacte".
                                       Acesta va fi utilizat pentru a stoca contactele.*/
    int contor=0;
    char optiune='0';
    while(optiune!=6)
    {
        cout<<"Meniu"<<endl;
        cout<<"1.Afiseaza lista de contacte"<<endl;
        cout<<"2.Adauga un contact"<<endl;
        cout<<"3.Cauta un contact"<<endl;
        cout<<"4.Actualizeaza un contact"<<endl;
        cout<<"5.Sterge un contact"<<endl;
        cout<<"6.Iesire"<<endl;
        cout<<endl;
        cout<<"Introduceti optiunea:";
        cin>>optiune;
         switch (optiune)
        {
        case '1':
          {
            cout<<"Lista de contacte:"<<endl;
            for (int i = 0; i < contor; i++)
            {
                cout<<"-------------------------"<<endl;
                contacte[i].afisare();
            }
            cout<<"-------------------------"<<endl;
            break;
          }
        case '2':
        {
            if (contor>=maxim_contacte)
            {
                cout<<"Lista de contacte este plina. Nu se mai pot adauga contacte noi."<<endl;
                break;
            }

            Contact c;
            char adaugaNume;
            cout<<"Doriti sa adaugati numele contactului? (D/N): ";
            cin>>adaugaNume;
            if (adaugaNume=='D' || adaugaNume=='d')
            {
                cout<<"Introduceti numele: ";
                cin>>c.nume;
            }

            char adaugaTelefon;
            cout<<"Doriti sa adaugati numarul de telefon fix? (D/N): ";
            cin>>adaugaTelefon;
            if(adaugaTelefon=='D' || adaugaTelefon=='d')
            {
                cout<<"Introduceti numarul de telefon fix: ";
                cin>>c.numar_telefon_fix;
                while(!este_numar(c.numar_telefon_fix))
            {
                    cout<<"Numarul de telefon trebuie sa contina doar cifre. Reintintroduceti numarul de telefon: ";
                    cin>>c.numar_telefon_fix;
            }
            }
        char adaugaMobil;
        cout<<"Doriti sa adaugati numarul de mobil? (D/N): ";
        cin>>adaugaMobil;
        if(adaugaMobil=='D' || adaugaMobil=='d')
        {
            cout<<"Introduceti numarul de mobil: ";
            cin>>c.numar_mobil;
            while(!este_numar(c.numar_mobil))
            {
                cout<< "Numarul de mobil trebuie sa contina doar cifre. Reintroduceti numarul de mobil: ";
                cin>>c.numar_mobil;
            }
        }
    char adaugaEmail;
        cout<<"Doriti sa adaugati adresa de email? (D/N): ";
        cin>>adaugaEmail;
        if(adaugaEmail == 'D' || adaugaEmail == 'd')
        {
            cout<<"Introduceti adresa de email: ";
            cin>>c.email;
        }

        char adaugaAdresa;
        cout<<"Doriti sa adaugati adresa? (D/N): ";
        cin>>adaugaAdresa;
        if (adaugaAdresa == 'D' || adaugaAdresa == 'd')
        {
            cout<<"Introduceti adresa: ";
            cin.ignore(); // Ignora caracterul newline din buffer
            getline(cin, c.adresa);
        }

        contacte[contor++] = c;
        cout<<"Contactul a fost adaugat cu succes."<<endl;
        break;
      }
      /*Opțiunea '2' din meniu permite utilizatorului să adauge un nou contact în lista de contacte.
      Utilizatorul poate adăuga informații precum nume, număr de telefon fix, număr de telefon mobil, adresă de email și adresa fizică.
      Verificări sunt realizate pentru a asigura introducerea corectă a datelor, cum ar fi validarea numerelor
      și întrebarea utilizatorului pentru a decide dacă dorește să introducă anumite informații.
      Contactul nou creat este stocat în array-ul "contacte", iar utilizatorului i se afișează un mesaj de confirmare.*/

    case '3':
    {
        string Nume;
        cout<<"Introduceti numele contactului pe care doriti sa il cautati: ";
        cin>>Nume;

        bool contactGasit = false;
        for (int i = 0; i < contor; i++)
        {
            if (contacte[i].nume == Nume)
            {
                cout<<"Contact gasit:" << endl;
                contacte[i].afisare();
                contactGasit = true;
                break;
            }
        }

        if (!contactGasit)
        {
            cout<<"Contactul cu numele "<<Nume<<" nu a fost gasit."<<endl;
        }
        break;
      }
      /*Opțiunea '3' din meniu permite utilizatorului să caute un contact în lista de contacte.
       Utilizatorul este invitat să introducă numele contactului pe care dorește să-l caute.
       Apoi, se parcurge lista de contacte și se verifică dacă numele introdus se potrivește cu numele unui contact existent.
       Dacă se găsește o potrivire, se afișează informațiile contactului găsit utilizând funcția "afisare()" definită în clasa "Contact".
       Dacă nu se găsește nicio potrivire, se afișează un mesaj corespunzător.*/
    case '4':
    {
        string Nume;
        cout<<"Introduceti numele contactului pe care doriti sa il actualizati: ";
        cin>>Nume;

        bool contactGasit = false;
        for(int i = 0; i < contor; i++)
        {
            if(contacte[i].nume == Nume)
            {
                cout<<"Contact gasit. Introduceti noile informatii:"<<endl;
                char actualizeazaTelefon;
                cout<<"Doriti sa actualizati numarul de telefon fix? (D/N): ";
                cin>>actualizeazaTelefon;
                if(actualizeazaTelefon == 'D' || actualizeazaTelefon == 'd')
               {
                cout<<"Introduceti numarul de telefon: ";
                cin>>contacte[i].numar_telefon_fix;
                while(!este_numar(contacte[i].numar_telefon_fix))
                {
                    cout<<"Numarul de telefon trebuie sa contina doar cifre. Reintroduceti numarul de telefon: ";
                    cin>>contacte[i].numar_telefon_fix;
                }
               }
                char actualizeazaMobil;
                cout<<"Doriti sa actualizati numarul de mobil? (D/N): ";
                cin>>actualizeazaMobil;
                if(actualizeazaMobil == 'D' || actualizeazaMobil == 'd')
                {
                    cout<<"Introduceti numarul de mobil: ";
                    cin>>contacte[i].numar_mobil;
                    while(!este_numar(contacte[i].numar_mobil))
                    {
                        cout<<"Numarul de mobil trebuie sa contina doar cifre. Reintroduceti numarul de mobil: ";
                        cin>>contacte[i].numar_mobil;
                    }
                }

                char actualizeazaEmail;
                cout<<"Doriti sa actualizati adresa de email? (D/N): ";
                cin>>actualizeazaEmail;
                if(actualizeazaEmail == 'D' || actualizeazaEmail == 'd')
                {
                    cout<<"Introduceti adresa de email: ";
                    cin>>contacte[i].email;
                }

                char actualizeazaAdresa;
                cout<<"Doriti sa actualizati adresa? (D/N): ";
                cin>>actualizeazaAdresa;
                if(actualizeazaAdresa == 'D' || actualizeazaAdresa == 'd')
                {
                    cout<<"Introduceti adresa: ";
                    cin.ignore(); // Ignora caracterul newline din buffer
                    getline(cin, contacte[i].adresa);
                }
                cout<<"Contactul a fost actualizat cu succes."<<endl;
                contactGasit = true;
                break;
             }
        }

        if (!contactGasit)
        {
            cout<<"Contactul cu numele "<<Nume<<" nu a fost gasit."<< endl;
        }
        break;
    }
    /*Opțiunea '4' din meniu permite utilizatorului să actualizeze informațiile unui contact existent.
    Utilizatorul este invitat să introducă numele contactului pe care dorește să-l actualizeze.
    Apoi, se parcurge lista de contacte și se verifică dacă numele introdus se potrivește cu numele unui contact existent.
    Dacă se găsește o potrivire, se afișează un mesaj de confirmare și utilizatorului i se solicită să introducă noile informații pentru contactul respectiv.
    Utilizatorul poate alege să actualizeze numărul de telefon fix, numărul de telefon mobil, adresa de email și adresa.
    Se efectuează verificări similare cu cele de adăugare a numerelor pentru a se asigura că noile numere introduse sunt valide.
    Informațiile contactului sunt actualizate direct în obiectul corespunzător din array-ul "contacte".
    La final, se afișează un mesaj de confirmare a actualizării contactului.
    Dacă nu se găsește nicio potrivire în listă pentru numele introdus, se afișează un mesaj corespunzător.*/

   case '5':
   {// Implementează ștergerea unui contact
            string sterge_numele;
            cout << "Introduceti numele contactului pe care doriti sa il stergeti: ";
            cin >> sterge_numele;
            bool contactGasit = false;
            for (int i = 0; i < contor; i++)
            {
                if (contacte[i].nume == sterge_numele)
                {
                    cout<<"Contact gasit:"<<endl;
                    contacte[i].afisare();
                    cout<<"Doriti sa stergeti acest contact? (D/N): ";
                    char confirmareStergere;
                    cin>>confirmareStergere;

                    if (confirmareStergere == 'D' || confirmareStergere == 'd')
                    {
                        // Sterge contactul
                        for (int j = i; j < contor - 1; j++)
                        {
                            contacte[j] = contacte[j + 1];
                        }
                        contor--;
                        cout<<"Contactul a fost sters cu succes."<<endl;
                    }
                    else
                    {
                        cout<<"Stergerea contactului a fost anulata."<<endl;
                    }

                    contactGasit = true;
                    break;
                }
            }

            if (!contactGasit)
            {
                cout<<"Contactul cu numele "<<sterge_numele<<" nu a fost gasit."<<endl;
            }
            break;

   }
   /*Opțiunea '5' din meniu permite utilizatorului să șteargă un contact din lista de contacte.
   Utilizatorul este invitat să introducă numele contactului pe care dorește să-l șteargă.
   Apoi, se parcurge lista de contacte și se verifică dacă numele introdus se potrivește cu numele unui contact existent.
   Dacă se găsește o potrivire, se afișează informațiile contactului găsit utilizând funcția "afisare()" definită în clasa "Contact".
   Utilizatorului i se solicită confirmarea pentru ștergerea contactului. Dacă confirmarea este primită,
   contactul este eliminat din lista prin deplasarea contactelor ulterioare cu o poziție spre stânga.
   Contorul este ajustat pentru a reflecta numărul actual de contacte din lista.
   La final, se afișează un mesaj de confirmare a ștergerii sau a anulării ștergerii.
   Dacă nu se găsește nicio potrivire în listă pentru numele introdus, se afișează un mesaj corespunzător.*/
    case '6':
   {
    cout<<"La revedere!"<<endl;
    break;
    default:
   {
    cout<<"Optiune invalida. Va rugam incercati din nou." << endl;
    break;
   }
   }
   }
    }
    return 0;
}
